package com.boardship.boardship_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardshipBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
